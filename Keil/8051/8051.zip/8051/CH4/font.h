#ifndef _font_h_
#define _font_h_
#ifdef __C51__
const unsigned char code font[8]={
#else
const unsigned char font[8]={
#endif
0xe0,
0xd7,
0xb7,
0x77,
0xb7,
0xd7,
0xe0,
0xff};
#endif