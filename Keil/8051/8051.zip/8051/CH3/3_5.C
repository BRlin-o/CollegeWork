/*********** 3_5.c ******************************************
*�ʧ@�G��RAMŪ���}�C��ƥ�LED��X
*************************************************************/
#include "..\AT89X52.H"  //�Ȧs���βպA�]�w
char TABLE[8]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80}; 
sfr    LED=0x80; //P0��LED��X
main()
{
  loop:
    LED=TABLE[0]; //LED=0x01
    LED=TABLE[1]; //LED=0x02
    LED=TABLE[2]; //LED=0x04
    LED=TABLE[3]; //LED=0x08
    LED=TABLE[4]; //LED=0x10
    LED=TABLE[5]; //LED=0x20
    LED=TABLE[6]; //LED=0x40
    LED=TABLE[7]; //LED=0x80
   goto loop;  
}